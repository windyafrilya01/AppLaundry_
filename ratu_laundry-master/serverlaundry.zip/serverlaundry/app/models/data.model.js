//app/models/orderpage.models.js
const sql = require("./db.js");
const Orderpage = function (orderpage) {
    this.title = orderpage.title;
    this.description = Orderpage.description;
    this.images = Orderpage.images;
};
//Mengambil semua data 
Orderpage.getAll = result => {
    sql.query("SELECT * FROM orderpage", (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(null, err);
            return;
        }
        console.log("result: ", res);
        result(null, res);
    });
};
// Mengambil data yang memiliki id = orderpageId
Orderpage.findById = (id, result) => {
    sql.query(`SELECT * FROM orderpage WHERE id = ${id}`, (err, res)=> {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }
        if (res.length) {
            console.log(res[0]);
            result(null, res[0]);
            return;
        }
        result({ kind: "not_found" }, null);
    });
};
// Membuat data baru
Orderpage.create = (neworderpage, result) => {
    console.log(newOrderpage);
    sql.query("INSERT INTO orderpage (title, description, images) VALUES (?,?,?)",
        [newOrderpage.title, newOrderpage.description, newOrderpage.images], (err,
            res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }
        console.log(res);
        console.log("buat data: ", {
            id: res.insertId, ...newOrderpage
        });
        result(null, { id: res.insertId, ...newOrderpage });
    });
};
// Mengupdate data yang memiliki id = id
Orderpage.updateById = (id, orderpage, result) => {
    sql.query(
        "UPDATE orderpage SET title = ?, description = ?, images = ? WHERE id = ?",
        [Orderpage.title, Orderpage.description, Orderpage.images, id],
        (err, res) => {
            if (err) {
                console.log("error: ", err);
                result(null, err);
                return;
            }
            if (res.affectedRows == 0) {
                result({ kind: "not_found" }, null);
                return;
            }
            console.log("update data: ", { id: id, ...Orderpage });
            result(null, { id: id, ...0rderpage });
        }
    );
};
// Menghapus data yang memiliki id = id
Orderpage.remove = (id, result) => {
    sql.query("DELETE FROM Orderpage WHERE id = ?", id, (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(null, err);
            return;
        }
        if (res.affectedRows == 0) {
            // not found Orderpage with the id
            result({ kind: "not_found" }, null);
            return;
        }
        console.log("hapus data dengan id: ", id);
        result(null, res);
    });
};
// Menghapus semua data
Orderpage.removeAll = result => {
    sql.query("DELETE FROM Orderpage", (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(null, err);
            return;
        }
        console.log(`Menghapus ${res.affectedRows} orderpage`);
        result(null, res);
    });
};
module.exports = Orderpage;