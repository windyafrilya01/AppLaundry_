module.exports = app => {
    const orderpage = require("../controller/orderpage.controller");
   
    //Mengambil semua data
    app.get("/api/orderpage", orderpage.findAll);
    //Mengambil data yang memiliki id = id
    app.get("/api/orderpage/:id", orderpage.findOne);
    //Membuat data baru
    app.post("/api/orderpage", orderpage.create);
    //Mengubah data yang memiliki id = id
    app.put("/api/orderpage/:id", orderpage.update);
    //Hapus data yang memiliki id = id
    app.delete("/api/orderpage/:id", orderpage.delete);
    //Hapus seluruh data
    app.delete("/api/orderpage", orderpage.deleteAll);
};